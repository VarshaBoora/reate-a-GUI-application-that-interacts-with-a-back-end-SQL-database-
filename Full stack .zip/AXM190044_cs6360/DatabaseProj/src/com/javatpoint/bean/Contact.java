package com.javatpoint.bean;

public class Contact {
private int contactid,phoneid,addressid,dateid;
private String firstname,lastname,middlename,number,phonetype,areacode,addresstype,address,city,state,zip,datetype,dateday;
private String searchtext;

public String getSearchtext() {
	return searchtext;
}
public void setSearchtext(String searchtext) {
	this.searchtext = searchtext;
}

public int getContactid() {
	return contactid;
}
public void setContactid(int contactid) {
	this.contactid = contactid;
}
public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public String getMiddlename() {
	return middlename;
}
public void setMiddlename(String middlename) {
	this.middlename = middlename;
}
//ADDRESS
public int getAddressid() {
	return addressid;
}
public void setAddressid(int addressid) {
	this.addressid = addressid;
}

public String getAddresstype() {
	return addresstype;
}
public void setAddresstype(String addresstype) {
	this.addresstype = addresstype;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getZip() {
	return zip;
}
public void setZip(String zip) {
	this.zip = zip;
}


//PHONE
public int getPhoneid() {
	return phoneid;
}
public void setPhoneid(int phoneid) {
	this.phoneid = phoneid;
}

public String getNumber() {
	return number;
}
public void setNumber(String number) {
	this.number = number;
}
public String getPhonetype() {
	return phonetype;
}
public void setPhonetype(String phonetype) {
	this.phonetype = phonetype;
}
public String getAreacode() {
	return areacode;
}
public void setAreacode(String areacode) {
	this.areacode = areacode;
}



//DATE
public int getDateid() {
	return dateid;
}
public void setDateid(int dateid) {
	this.dateid = dateid;
}

public String getDatetype() {
	return datetype;
}
public void setDatetype(String datetype) {
	this.datetype = datetype;
}
public String getDateday() {
	return dateday;
}
public void setDateday(String dateday) {
	this.dateday = dateday;
}

}
